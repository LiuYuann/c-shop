/*
    @�������ƣ�freeUser   ��ڲ���:userLink pUser
    @�������ܣ��ͷ��û����
*/
void freeUser(userLink pUser)
{
    creditLink pCreadit;
    while(pUser->creditHead)
    {
        pCreadit=pUser->creditHead;
        pUser->creditHead=pUser->creditHead->next;
        free(pCreadit);
    }
    addressLink pAddress;
    while(pUser->addressHead)
    {
        pAddress=pUser->addressHead;
        pUser->addressHead=pUser->addressHead->next;
        free(pAddress);
    }
    shoppingCarLink pShoppingCar;
    while(pUser->shoppingCarHead)
    {
        pShoppingCar=pUser->shoppingCarHead;
        pUser->shoppingCarHead=pUser->shoppingCarHead->next;
        free(pShoppingCar);
    }
    shoppingRecordLink pShoppingRecord;
    while(pUser->shoppingRecordHead)
    {
        pShoppingRecord=pUser->shoppingRecordHead;
        pUser->shoppingRecordHead=pUser->shoppingRecordHead->next;
        free(pShoppingRecord);
    }
    recordLink pRecord;
    while(pUser->recordHead)
    {
        pRecord=pUser->recordHead;
        pUser->recordHead=pUser->recordHead->next;
        free(pRecord);
    }
    free(pUser);
}
/*
    @�������ƣ�freeMerchant   ��ڲ���:merchantLink head
    @�������ܣ��ͷ��̼ҽ��
*/
void freeMerchant(merchantLink pMerchant)
{
    goodsLink pGoods;
    while(pMerchant->goodsHead)
    {
        pGoods=pMerchant->goodsHead;
        pMerchant->goodsHead=pMerchant->goodsHead->next;
        free(pGoods);
    }
    free(pMerchant);
}

/*
    @�������ƣ�writeMerchantToFile   ��ڲ���:merchantLink head,char *filename
    @�������ܣ����̼���Ϣ�����ļ�
*/
void writeMerchantToFile(merchantLink head,char *filename)
{
    FILE *fp;
    fp=fopen(filename,"wb");
    merchantLink pMerchant=head->next;
    goodsLink pGoods;
    if(fp!=NULL)
    {
        while(pMerchant)
        {
            fwrite(pMerchant,sizeof(merchantNode),1,fp);
            pGoods=pMerchant->goodsHead->next;
            while(pGoods)
            {
                fwrite(pGoods,sizeof(goodsNode),1,fp);
                pGoods=pGoods->next;
            }
            pMerchant=pMerchant->next;
        }
    }
    else
        printf("�ļ�����ʧ�ܣ�\n");
    fclose(fp);
}

/*
    @�������ƣ�cleanTwoSpace   ��ڲ���:char a[]
    @�������ܣ�����ַ���a���˵Ŀո�
*/
void cleanTwoSpace(char a[])
{
    int i=0,j=strlen(a)-1,k=0;
    char b[j];
    while(j>0&&a[j]==32)
    {
        j--;
    }
    a[++j]='\0';
    while(i<j&&a[i]==32)
    {
        i++;
    }
    while(i<j)
        b[k++]=a[i++];
    b[k]='\0';
    strcpy(a,b);
}

/*
    @�������ƣ�freeUserLink   ��ڲ���:userLink head
    @�������ܣ��ͷ��û�����
*/
void freeUserLink(userLink head)
{
    userLink pUser;
    while(head)
    {
        pUser=head;
        head=head->next;
        freeUser(pUser);
    }
}

/*
    @�������ƣ�freeMerchantLink   ��ڲ���:merchantLink head
    @�������ܣ��ͷ��̼�����
*/
void freeMerchantLink(merchantLink head)
{
    merchantLink pMerchant;
    while(head)
    {
        pMerchant=head;
        head=head->next;
        freeMerchant(pMerchant);
    }
}

/*
    @�������ƣ�writeUserToFile   ��ڲ���:userLink head,char *filname
    @�������ܣ����û�����д���ļ�
*/
void writeUserToFile(userLink head,char *filname)//���û�����д���ļ�
{
    FILE *fp;
    fp=fopen(filname,"wb");
    userLink pUser=head->next;
    creditLink pCreadit;
    addressLink pAddress;
    shoppingCarLink pShoppingCar;
    shoppingRecordLink pShoppingRecord;
    recordLink pRecord;
    if(fp!=NULL)
    {
        while(pUser)
        {
            fwrite(pUser,sizeof(userNode),1,fp);
            pCreadit=pUser->creditHead->next;
            while(pCreadit)
            {
                fwrite(pCreadit,sizeof(creditNode),1,fp);
                pCreadit=pCreadit->next;
            }
            pAddress=pUser->addressHead->next;
            while(pAddress)
            {
                fwrite(pAddress,sizeof(addressNode),1,fp);
                pAddress=pAddress->next;
            }
            pShoppingCar=pUser->shoppingCarHead->next;
            while(pShoppingCar)
            {
                fwrite(pShoppingCar,sizeof(shoppingCarNode),1,fp);
                pShoppingCar=pShoppingCar->next;
            }
            pShoppingRecord=pUser->shoppingRecordHead->next;
            while(pShoppingRecord)
            {
                fwrite(pShoppingRecord,sizeof(shoppingRecordNode),1,fp);
                pShoppingRecord=pShoppingRecord->next;
            }
            pRecord=pUser->recordHead->next;
            while(pRecord)
            {
                fwrite(pRecord,sizeof(recordNode),1,fp);
                pRecord=pRecord->next;
            }
            pUser=pUser->next;
        }
        fclose(fp);
    }
    else
        printf("�ļ�����ʧ�ܣ�\n");
}

/*
    @�������ƣ�readUserFromFile   ��ڲ���:userLink head,char *filename
    @�������ܣ����ļ��ж�ȡ�û�����
*/
void readUserFromFile(userLink head,char *filename)
{
    FILE *fp;
    int k,j;
    fp=fopen(filename,"rb");
    userLink pUser,preUser=head;
    creditLink pCreadit,preCreadit;
    addressLink pAddress,preAddress;
    shoppingCarLink pShoppingCar,preShoppingCar;
    shoppingRecordLink pShoppingRecord,preShoppingRecord;
    recordLink pRecord,preRecord;
    if(fp!=NULL)
    {
        while(!feof(fp))
        {
            pUser=(userLink)malloc(sizeof(userNode));
            k=fread(pUser,sizeof(userNode),1,fp);
            if(k==1)
            {
                pUser->creditHead=(creditLink)malloc(sizeof(creditNode));
                preCreadit=pUser->creditHead;
                for(j=0;j<pUser->creditCount;j++)
                {
                    pCreadit=(creditLink)malloc(sizeof(creditNode));
                    fread(pCreadit,sizeof(creditNode),1,fp);
                    preCreadit->next=pCreadit;
                    preCreadit=pCreadit;
                }
                preCreadit->next=NULL;

                pUser->addressHead=(addressLink)malloc(sizeof(addressNode));
                preAddress=pUser->addressHead;
                for(j=0;j<pUser->addressCount;j++)
                {
                    pAddress=(addressLink)malloc(sizeof(addressNode));
                    fread(pAddress,sizeof(addressNode),1,fp);
                    preAddress->next=pAddress;
                    preAddress=pAddress;
                }
                preAddress->next=NULL;

                pUser->shoppingCarHead=(shoppingCarLink)malloc(sizeof(shoppingCarNode));
                preShoppingCar=pUser->shoppingCarHead;
                for(j=0;j<pUser->shoppingCarCount;j++)
                {
                    pShoppingCar=(shoppingCarLink)malloc(sizeof(shoppingCarNode));
                    fread(pShoppingCar,sizeof(shoppingCarNode),1,fp);
                    preShoppingCar->next=pShoppingCar;
                    preShoppingCar=pShoppingCar;
                }
                preShoppingCar->next=NULL;

                pUser->shoppingRecordHead=(shoppingRecordLink)malloc(sizeof(shoppingRecordNode));
                preShoppingRecord=pUser->shoppingRecordHead;
                for(j=0;j<pUser->shoppingRecordCount;j++)
                {
                    pShoppingRecord=(shoppingRecordLink)malloc(sizeof(shoppingRecordNode));
                    fread(pShoppingRecord,sizeof(shoppingRecordNode),1,fp);
                    preShoppingRecord->next=pShoppingRecord;
                    preShoppingRecord=pShoppingRecord;
                }
                preShoppingRecord->next=NULL;

                pUser->recordHead=(recordLink)malloc(sizeof(recordNode));
                preRecord=pUser->recordHead;
                for(j=0;j<pUser->recordCount;j++)
                {
                    pRecord=(recordLink)malloc(sizeof(recordNode));
                    fread(pRecord,sizeof(recordNode),1,fp);
                    preRecord->next=pRecord;
                    preRecord=pRecord;
                }
                preRecord->next=NULL;

                preUser->next=pUser;
                preUser=pUser;
            }
            else
            {
               preUser->next=NULL;
               break;
            }
        }
        fclose(fp);
    }
    else
        printf("�ļ���ȡʧ�ܣ�\n");
}

/*
    @�������ƣ�printStar   ��ڲ���:char star[],int n
    @�������ܣ���ӡn��star�ַ���
*/
void printStar(char star[],int n)
{
    while(n>0)
    {
        printf("%s",star);
        n--;
    }
}

/*
    @�������ƣ�printSpace   ��ڲ���:int n
    @�������ܣ���ӡn���ո�
*/
void printSpace(int n)
{
    while(n>0)
    {
        printf(" ");
        n--;
    }
}

/*
    @�������ƣ�showTime   ��ڲ���:char nowTime[]
    @�������ܣ����ϵͳʱ��
*/
void showTime(char nowTime[])
{
    time_t rawtime;
    struct tm * timeinfo;
    char nowtime[20];
    time(&rawtime);
    timeinfo = localtime (&rawtime);
    strftime (nowtime,sizeof(nowtime),"%Y-%m-%d %H:%M:%S",timeinfo);
    strcpy(nowTime,nowtime);
}

/*
    @�������ƣ�printTime   ��ڲ���:char a[]
    @�������ܣ���ӡʱ��ͻ�ӭ���
*/
void printTime(char a[])
{
    system("cls");
    char nowTime[20];
    showTime(nowTime);
    printf("%s\n\n",nowTime);
    printf("�𾴵�%s,��ã�\n\n",a);
}

/*
    @�������ƣ�printString   ��ڲ���:char star[],char str[],int length
    @�������ܣ���ӡ�ַ���
*/
void printString(char star[],char str[],int length)
{
    int i;
    for(i=0;i<(length-strlen(str))/2;i++)
        printf("%s",star);
    printf("%s",str);
    for(i=0;i<(length-strlen(str))/2;i++)
        printf("%s",star);
    if((length+strlen(str))%2==1)
        printf("%s",star);
    printf("\n");
}

/*
    @�������ƣ�inputInstruction   ��ڲ���:char tishiyu[],char a,char error[]
    @�������ܣ�����ָ�� '0'-a��������ȷ����ָ��ֵ�����������ش�����ʾ
*/
int inputInstruction(char tishiyu[],char a,char error[])
{
    char c,b='\0';
    int i=0,n=1;
    int s;
    int l=1;
    if(strlen(tishiyu)<SM)
        s=SM;
    else
        s=strlen(tishiyu)+1;

    printf("%s",tishiyu);
    printStar(" ",s-strlen(tishiyu));
    printf("��");
    printStar(" ",2*l+n);
    printf("��");
    printStar("\b",2+l+n);
    while(1)
    {
        c=getch();
        if(c=='\r')
        {
            if(i<1)
            {
                printStar(" ",l+n-i);
                printf("��");
                printStar(" ",2*l);
                printf("�����Ϊ�գ�");
                Sleep(M);
                printStar("\b \b",strlen("�����Ϊ�գ�"));
                printStar("\b",2+3*l+n-i);
            }
            else
                break;
        }
        else
            if(i>0&&c==8)
            {
                printf("\b \b");
                i--;
            }
            else
                if(i<1&&c>='0'&&c<=a)
            {
                printf("%c",c);
                b=c;
                i++;
            }
            else
                if(i<1&&(c<'0'||c>a))
            {
                printStar(" ",l+n-i);
                printf("��");
                printStar(" ",2*l);
                printf("%s",error);
                Sleep(M);
                printStar("\b \b",strlen(error));
                printStar("\b",2+3*l+n-i);
            }
    }
    printf("\n");
    return b-'0';
}

/*
    @�������ƣ�creatMerchant   ��ڲ���:��
    @�������ܣ������̼�ͷ���,����merchantLink ����ָ��
*/
merchantLink creatMerchant()
{
    merchantLink head=(merchantLink)malloc(sizeof(merchantNode));
    head->next=NULL;
    head->goodsHead=(goodsLink)malloc(sizeof(goodsNode));
    head->goodsHead->next=NULL;
    head->goodsCount=0;
    return head;
}

/*
    @�������ƣ�creatUser   ��ڲ���:��
    @�������ܣ������û�ͷ��㣬����userLink ����ָ��
*/
userLink creatUser()
{
    userLink head=(userLink)malloc(sizeof(userNode));
    head->next=NULL;
    head->addressHead=(addressLink)malloc(sizeof(addressNode));
    head->addressHead->next=NULL;
    head->creditHead=(creditLink)malloc(sizeof(creditNode));
    head->creditHead->next=NULL;
    head->shoppingCarHead=(shoppingCarLink)malloc(sizeof(shoppingCarNode));
    head->shoppingCarHead->next=NULL;
    head->shoppingRecordHead=(shoppingRecordLink)malloc(sizeof(shoppingRecordNode));
    head->shoppingRecordHead->next=NULL;
    head->recordHead=(recordLink)malloc(sizeof(recordNode));
    head->recordHead->next=NULL;
    head->addressCount=0;
    head->creditCount=0;
    head->shoppingCarCount=0;
    head->shoppingRecordCount=0;
    head->recordCount=0;
    return head;
}

/*
    @�������ƣ�readMerchantFromFile   ��ڲ���:merchantLink head,char *filename
    @�������ܣ����ļ��ж�ȡ�̼�����
*/
void readMerchantFromFile(merchantLink head,char *filename)
{
    int k,j;
    FILE *fp;
    fp=fopen(filename,"rb");
    merchantLink pMerchant,preMerchant=head;
    goodsLink pGoods,preGoods;
    if(fp!=NULL)
    {
        while(!feof(fp))
        {
            pMerchant=(merchantLink)malloc(sizeof(merchantNode));
            k=fread(pMerchant,sizeof(merchantNode),1,fp);
            if(k==1)
            {
               pMerchant->goodsHead=(goodsLink)malloc(sizeof(goodsNode));
               preGoods=pMerchant->goodsHead;
               for(j=0;j<pMerchant->goodsCount;j++)
               {
                   pGoods=(goodsLink)malloc(sizeof(goodsNode));
                   fread(pGoods,sizeof(goodsNode),1,fp);
                   preGoods->next=pGoods;
                   preGoods=pGoods;
               }
               preGoods->next=NULL;

               preMerchant->next=pMerchant;
               preMerchant=pMerchant;
            }
            else
            {
                preMerchant->next=NULL;
                break;
            }

        }
    }
    else
        printf("�ļ���ȡʧ�ܣ�\n");
    fclose(fp);
}

/*
    @�������ƣ�inputString   ��ڲ���:char name[],char tishiyu[],char error[],int n
    @�������ܣ��������Ҫ����ַ���
*/
void inputString(char name[],char tishiyu[],char error[],int n)
{

    int s;//��ʾ�ﳤ��
    int l=1;//���ұߵĿո�
    int loop=1;
    char tempName[5*n];
    if(strlen(tishiyu)<SM)
        s=SM;
    else
        s=strlen(tishiyu)+1;
    while(loop)
    {

        printf("%s",tishiyu);
        printStar(" ",s-strlen(tishiyu));
        printf("��");
        printStar(" ",n+2*l);
        printf("��");
        printStar("\b",2+l+n);
        gets(tempName);
        cleanTwoSpace(tempName);
        if(strlen(tempName)<=n&&strlen(tempName)>0)
        {
            strcpy(name,tempName);
            loop=0;
        }
        else
        {

                if(strlen(tempName)==0)
                {
                    printf("�����Ϊ�գ����������룡\n");
                }
                else
                {

                    printf("%s\n",error);
                }
        }
    }
}

/*
    @�������ƣ�inputPhone   ��ڲ���:char phone[],char tishiyu[],int n
    @�������ܣ��������Ҫ��ĵ绰����
*/
void inputPhone(char phone[],char tishiyu[],int n)
{
    int loop=1;
    char c;
    int i=0;
    int s;
    int l=1;
    if(strlen(tishiyu)<SM)
        s=SM;
    else
        s=strlen(tishiyu)+1;

    printf("%s",tishiyu);
    printStar(" ",s-strlen(tishiyu));
    printf("��");
    printStar(" ",2*l+n);
    printf("��");
    printStar("\b",2+l+n);
    while(loop)
    {
        while(1)
        {
            c=getch();
            if(c=='\r')
            {
                if(i<n)
                {
                    printStar(" ",l+n-i);
                    printf("��");
                    printStar(" ",2*l);
                    printf("���볤�Ȳ���11λ��");
                    Sleep(M);
                    printStar("\b \b",strlen("���볤�Ȳ���11λ��"));
                    printStar("\b",2+3*l+n-i);
                }
                else
                    break;
            }
            else
                if(i>0&&c==8)
                {
                    printf("\b \b");
                    i--;
                }
                else
                    if(i<n&&c>='0'&&c<='9')
                {
                    printf("%c",c);
                    phone[i++]=c;
                }
        }
        if((phone[0]=='1'&&(phone[1]=='3'||phone[1]=='5'||phone[1]=='8'))||(phone[0]=='1'&&phone[1]=='5'&&phone[2]!='4'))
            loop=0;
        else
        {
            printStar(" ",l+n-i);
            printf("��");
            printStar(" ",2*l);
            printf("���벻���ڣ�");
            Sleep(M);
            printStar("\b \b",strlen("���벻���ڣ�"));
            printStar("\b",2+3*l+n-i);
        }
    }
    phone[i]='\0';
    printf("\n");
}

/*
    @�������ƣ�findPhone   ��ڲ���:userLink head,char phone[]
    @�������ܣ����û���Ϣ������Ѱ�ҵ绰����Ϊphone���û��ڵ㣬���ҵ��򷵻ظýڵ㣬���򷵻�NULL
*/
userLink findPhone(userLink head,char phone[])
{
    userArrayLink temp=(userArrayLink)malloc(sizeof(userArrayNode));
    temp->length=0;
    int i=0;
    userLink p=head->next;
    while(p)
    {
        temp->user[i++]=p;
        temp->length++;
        p=p->next;
    }
    int left=0,right=temp->length-1,mid;
    while(left<=right)
    {
        mid=(left+right)/2;
        if(strcmp(temp->user[mid]->userCellphone,phone)==0)
            return temp->user[mid];
        else
            if(strcmp(temp->user[mid]->userCellphone,phone)>0)
            right=mid-1;
        else
            left=mid+1;
    }
    return NULL;
}

userLink findPhone1(userLink head,char phone[])//���û���������phone
{
    userLink p;
    p=head->next;
    while(p&&strcmp(phone,p->userCellphone)!=0)
    {
        p=p->next;
    }
    if(p)
        return p;
    else
        return NULL;
}

/*
    @�������ƣ�inputLoginPassword   ��ڲ���:char password[],char tishiyu[],int n
    @�������ܣ��������Ҫ��ĵ�¼����
*/
void inputLoginPassword(char password[],char tishiyu[],int n)
{
    int s;//��ʾ�ﳤ��
    int l=1;//���ұߵĿո�
    int i=0,counter=0;
    char c;
    if(strlen(tishiyu)<SM)
        s=SM;
    else
        s=strlen(tishiyu)+1;

    printf("%s",tishiyu);
    printStar(" ",s-strlen(tishiyu));
    printf("��");
    printStar(" ",2*l+n);
    printf("��");
    printStar("\b",2+l+n);
    while(1)
    {
        c=getch();
        if(c=='\r')
        {
            if(i<5)
            {
                printStar(" ",n+l-i);
                printf("��");
                printStar(" ",2*l);
                printf("���Ȳ���5λ��");
                Sleep(M);
                printStar("\b \b",strlen("���Ȳ���5λ��"));
                printStar("\b",2+3*l+n-i);
            }
            else
                if(i>=5&&counter<1)
            {
                printStar(" ",n+l-i);
                printf("��");
                printStar(" ",2*l);
                printf("����Ҫ����һ����ĸ��");
                Sleep(M);
                printStar("\b \b",strlen("����Ҫ����һ����ĸ��"));
                printStar("\b",2+3*l+n-i);
            }
            else
                break;
        }

        else if(i>0&&c==8)
        {
            printf("\b \b");
            i--;
        }
        else if(i<n&&((c>='0'&&c<='9')||(c>='A'&&c<='Z')||(c>='a'&&c<='z')))
        {
            if((c>='A'&&c<='Z')||(c>='a'&&c<='z'))
                counter++;
            password[i++]=c;
            printf("%c",c);
            Sleep(N);
            printf("\b \b");
            printf("*");
        }
    }
    password[i]='\0';
    printf("\n");
}

/*
    @�������ƣ�insertUser   ��ڲ���:userLink head,userLink q
    @�������ܣ������û��ڵ�
*/
void insertUser(userLink head,userLink q)
{
    userLink pre,p;
    pre=head;
    p=head->next;
    while(p&&strcmp(q->userCellphone,p->userCellphone)>0)
    {
        pre=p;
        p=p->next;
    }
    q->next=pre->next;
    pre->next=q;
}

/*
    @�������ƣ�getVerificationCode   ��ڲ���:char verificationCode[],int n
    @�������ܣ�����nλ��֤��
*/
void getVerificationCode(char verificationCode[],int n)
{
    char str[]="0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    int i;
    srand(time(NULL));
    for(i=0;i<n;i++)
        verificationCode[i]=str[rand()%62];
    verificationCode[n]='\0';
}

/*
    @�������ƣ�verificatione   ��ڲ���:char tishiyu[],int n
    @�������ܣ�������֤�벢�Ƚ��Ƿ���ȷ
*/
void verification(char tishiyu[],int n)
{
    int i=0,loop=1;
    char verificationCode[n+1];
    char temp[n+1];
    char c;
    int s;//�ո���
    int l=1;//�����ұ߿ո���
    if(strlen(tishiyu)<SM)
        s=SM;
    else
        s=strlen(tishiyu)+1;

    printf("%s",tishiyu);
    printStar(" ",s-strlen(tishiyu));
    while(loop)
    {
        printf("��");
        printStar(" ",2*l+n);
        printf("��");
        getVerificationCode(temp,n);
        printStar(" ",2*l);
        printf("%s",temp);
        printStar("\b",2*n+3*l+2);
        while(1)
        {
            c=getch();
            if(i>0&&c==8)
            {
                printf("\b \b");
                i--;
            }

           else if(c=='\r') break;
           else if(i<n&&((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')))
            {
                verificationCode[i++]=c;
                printf("%c",c);
            }
        }
        verificationCode[i]='\0';
        if(strcasecmp(verificationCode,temp)!=0)
        {
            printStar(" ",n+l-i);
            printf("��");
            printStar(" ",2*l);
            printf("%s",temp);
            printStar(" ",2*l);
            printf("������֤������");
            Sleep(2*M);
            printStar("\b \b",strlen("������֤������")+4+6*l+2*n);
                i=0;
        }
        else
            loop=0;
    }
    printf("\n");
}

/*
    @�������ƣ�inputPayPassword   ��ڲ���:char password[],char tishiyu[],int n
    @�������ܣ��������Ҫ���֧������
*/
void inputPayPassword(char password[],char tishiyu[],int n)
{
    int s;//��ʾ�ﳤ��
    int l=1;//���ұߵĿո�
    int i=0;
    char c;
    if(strlen(tishiyu)<SM)
        s=SM;
    else
        s=strlen(tishiyu)+1;

    printf("%s",tishiyu);
    printStar(" ",s-strlen(tishiyu));
    printf("��");
    printStar(" ",2*l+n);
    printf("��");
    printStar("\b",2+l+n);
    while(1)
    {
        c=getch();
        if(c=='\r')
        {
            if(i<n)
            {
                printStar(" ",n+l-i);
                printf("��");
                printStar(" ",2*l);
                printf("���Ȳ���6λ��");
                Sleep(M);
                printStar("\b \b",strlen("���Ȳ���6λ��"));
                printStar("\b",2+3*l+n-i);
            }
            else
                break;
        }

        else if(i>0&&c==8)
        {
            printf("\b \b");
            i--;
        }
        else if(i<n&&c>='0'&&c<='9')
        {
            password[i++]=c;
            printf("%c",c);
            Sleep(N);
            printf("\b \b");
            printf("*");
        }
        else
            if(i<n&&((c>='a'&&c<='z')||(c>='A'&&c<='Z')))
        {
            printStar(" ",n+l-i);
            printf("��");
            printStar(" ",2*l);
            printf("ֻ���������֣�");
            Sleep(M);
            printStar("\b \b",strlen("ֻ���������֣�"));
            printStar("\b",2+3*l+n-i);
        }
    }
    password[i]='\0';
    printf("\n");
}

/*
    @�������ƣ�inputSelect   ��ڲ���:char remind[]
    @�������ܣ�ѡ���Ƿ�ͬ�⣬ͬ�ⷵ��1����ͬ�ⷵ��0
*/
int inputSelect(char remind[])
{
    int n=1;
    char c,a='\0';
    int i=0;
    int s=20;
    int l=1;
    printf("%s",remind);
    printStar(" ",s-strlen(remind));
    printf("��");
    printStar(" ",2*l+n);
    printf("��");
    printStar("\b",2+l+n);
    while(1)
    {
        c=getch();
        if(c=='\r')
        {
            if(i<1)
            {
                printStar(" ",l+n-i);
                printf("��");
                printStar(" ",2*l);
                printf("�����Ϊ�գ�");
                Sleep(M);
                printStar("\b \b",strlen("�����Ϊ�գ�"));
                printStar("\b",2+3*l+n-i);
            }
            else
                break;
        }
        else
            if(i>0&&c==8)
            {
                printf("\b \b");
                i--;
            }
            else
                if(i<1&&(c=='y'||c=='Y'||c=='n'||c=='N'))
            {
                printf("%c",c);
                a=c;
                i++;
            }
    }
    printf("\n");
    if(a=='y'||a=='Y')
        return 1;
    else
        return 0;
}

/*
    @�������ƣ�inputNewNumber   ��ڲ���:char tishiyu[],char error[],int minNumber,int maxNumber,int n
    @�������ܣ�����һ���Ĳ�Ϊ0�����֣�����Ҫ���򷵻أ�������������ʾ
*/
int inputNewNumber(char tishiyu[],char error[],int minNumber,int maxNumber,int n)//tishiyu��ʾ��  error������ʾ  n����֮��Ŀո񳤶�
{
    char c;
    char number[n+1];
    number[0]='\0';
    int i=0;
    int s;
    int l=1;
    if(strlen(tishiyu)<SM)
        s=SM;
    else
        s=strlen(tishiyu)+1;
    printf("%s",tishiyu);
    printStar(" ",s-strlen(tishiyu));
    printf("��");
    printStar(" ",2*l+n);
    printf("��");
    printStar("\b",2+l+n);
    while(1)
    {
        c=getch();
        if(c=='\r')
        {
            if(atoi(number)==0)
            {
                printStar(" ",l+n-i);
                printf("��");
                printStar(" ",2*l);
                printf("��������ȷ�����֣�");
                Sleep(M);
                printStar("\b \b",strlen("��������ȷ�����֣�"));
                printStar("\b",2+3*l+n-i);
            }
            else
                if(atoi(number)>maxNumber||atoi(number)<minNumber)
            {
                printStar(" ",l+n-i);
                printf("��");
                printStar(" ",2*l);
                printf("%s",error);
                Sleep(M);
                printStar("\b \b",strlen(error));
                printStar("\b",2+3*l+n-i);
            }
            else
                break;
        }
        else
            if(i>0&&c==8)
            {
                printf("\b \b");
                i--;
                number[i+1]='\0';
            }
            else
                if(i<n&&c>='0'&&c<='9')
            {
                printf("%c",c);
                number[i++]=c;
                number[i]='\0';
            }
    }
    printf("\n");
    return atoi(number);
}

/*
    @�������ƣ�inputCredit   ��ڲ���:char credit[],char tishiyu[],int n
    @�������ܣ�������ȷ�����п�����
*/
void inputCredit(char credit[],char tishiyu[],int n)
{
    int i=0,loop=1;
    int s=SM;//�ո���
    int l=1;//�����ұ߿ո���
    char c;
    if(strlen(tishiyu)<SM)
        s=strlen(tishiyu);
    printf("%s",tishiyu);
    printStar(" ",s-strlen(tishiyu));
    printf("��");
    printStar(" ",2*l+n);
    printf("��");
    printStar("\b",2+l+n);
    while(loop)
    {
        while(1)
        {
            c=getch();
            if(i>0&&c==8)
            {
                printf("\b \b");
                i--;
            }
            else
                if(c=='\r')
            {
                if(i<16)
                {
                    printStar(" ",l+n-i);
                    printf("��");
                    printStar(" ",2*l);
                    printf("���п���λ�����㣡");
                    Sleep(M);
                    printStar("\b \b",strlen("���п���λ�����㣡"));
                    printStar("\b",3*l+2+n-i);
                }
                else
                    break;
            }
            else
                if(i<n&&c>='0'&&c<='9')
                {
                    credit[i++]=c;
                    printf("%c",c);
                }
        }

        if(!((credit[0]=='3'&&(credit[1]=='5'||credit[1]=='7'))||credit[0]=='4'||credit[0]=='5'||credit[0]=='6'))
        {
            printStar(" ",l+n-i);
            printf("��");
            printStar(" ",2*l);
            printf("���п��Ų����ڣ�");
            Sleep(M);
            printStar("\b \b",strlen("���п��Ų����ڣ�"));
            printStar("\b",3*l+2+n-i);
        }
        else
            loop=0;
    }
    credit[i]='\0';
    printf("\n");
}

/*
    @�������ƣ�inputPrice   ��ڲ���:char tishiyu[],char error[],double maxNumber
    @�������ܣ�����Ǯ��������ȷ�򷵻أ�������������ʾ
*/
double inputPrice(char tishiyu[],char error[],double maxNumber)
{
    int n=12;
    char money[n+1];
    money[0]='\0';
    int i=0,point=0;
    int s;//�ո���
    int l=1;//�����ұ߿ո���
    char c;
    if(strlen(tishiyu)<SM)
        s=SM;
    else
        s=strlen(tishiyu)+1;
    printf("%s",tishiyu);
    printStar(" ",s-strlen(tishiyu));
    printf("��");
    printStar(" ",2*l+n);
    printf("��");
    printStar("\b",2+l+n);
    while(1)
    {
        c=getch();
        if(c=='\r')
        {
            if(atof(money)==0)
            {
                printStar(" ",n+l-i);
                printf("��");
                printStar(" ",2*l);
                printf("��������ȷ�Ľ��");
                Sleep(M);
                printStar("\b \b",strlen("��������ȷ�Ľ��"));
                printStar("\b",2+3*l+n-i);
            }
            else
                if(atof(money)>maxNumber)
            {
                printStar(" ",n+l-i);
                printf("��");
                printStar(" ",2*l);
                printf("%s",error);
                Sleep(M);
                printStar("\b \b",strlen(error));
                printStar("\b",2+3*l+n-i);
            }
            else
                break;
        }
        else
            if(i>0&&c==8)
        {
            if(i==point)
                point--;
            i--;
            money[i]='\0';
            printf("\b \b");
        }
        else
            if(i<n&&c=='.'&&i==point)
        {
            if(i==0)
            {
                money[i++]='0';
                point=1;
                printf("0.");
            }
            else
            {
                printf("%c",c);
            }
            money[i++]=c;
        }
        else
            if(i<n&&i-point<=2&&c>='0'&&c<='9')
            {
                if(point==i)
                    point++;
                money[i++]=c;
                printf("%c",c);
                money[i]='\0';
            }
    }
    printf("\n");
    return atof(money);
}

/*
    @�������ƣ�match   ��ڲ���:char s[],char t[]
    @�������ܣ����ַ���s��Ѱ��t�ַ������ҵ�����1�����򷵻�0
*/
int match(char s[],char t[])
{
    int i=0,j=0;
    if(strlen(t)<3)
        while(strlen(s)-i>strlen(t)&&j<strlen(t))
        {
            if(s[i++]==t[j])
                j++;
            else
                j=0;
        }
    else
        while(i<strlen(s)&&j<strlen(t)&&strlen(t)>0&&(strlen(s)-i)>=(strlen(t)-j))
        {
            if(s[i++]==t[j])
                j++;
        }
    if(strlen(t)==j)
        return 1;
    else
        return 0;
}

/*
    @�������ƣ�inputManyNumber   ��ڲ���:char tishiyu[],char error[],int minNumber,int maxNumber,int n
    @�������ܣ�����һ������Ϊ0�����֣�����Ҫ���򷵻أ�������������ʾ
*/
int inputManyNumber(char tishiyu[],char error[],int minNumber,int maxNumber,int n)//tishiyu��ʾ��  error������ʾ  n����֮��Ŀո񳤶�
{
    char c;
    char number[n+1];
    number[0]='\0';
    int i=0;
    int s;
    int l=1;
    if(strlen(tishiyu)<SM)
        s=SM;
    else
        s=strlen(tishiyu)+1;
    printf("%s",tishiyu);
    printStar(" ",s-strlen(tishiyu));
    printf("��");
    printStar(" ",2*l+n);
    printf("��");
    printStar("\b",2+l+n);
    while(1)
    {
        c=getch();
        if(c=='\r')
        {

            if(atoi(number)>maxNumber||atoi(number)<minNumber)
            {
                printStar(" ",l+n-i);
                printf("��");
                printStar(" ",2*l);
                printf("%s",error);
                Sleep(M);
                printStar("\b \b",strlen(error));
                printStar("\b",2+3*l+n-i);
            }
            else
                break;
        }
        else
            if(i>0&&c==8)
            {
                printf("\b \b");
                i--;
                number[i]='\0';
            }
            else
                if(i<n&&c>='0'&&c<='9')
            {
                printf("%c",c);
                number[i++]=c;
                number[i]='\0';
            }
    }
    printf("\n");
    return atoi(number);
}
