#include "version1.h"
#include "version2.h"
#include "version3.h"
#include "version4.h"

void selectIdentity()//����ѡ��
{
    system("cls");
    char nowTime[20];
    showTime(nowTime);
    printf("%s\n\n",nowTime);
    printf("��ѡ��������ݣ�\n\n");
    printStar("=",40);
    printf("\n");
    printStar(" ",sp);
    printf("*   1.�û�     *\n");
    printf("\n");
    printStar(" ",sp);
    printf("*   2.�̼�     *\n");
    printf("\n");
    printStar(" ",sp);
    printf("*   0.����     *\n");
    printStar("=",40);
    printf("\n");
}
int main()
{
    int i;
    do
    {
        selectIdentity();
        i=inputInstruction("������ѡ�",'2',"��������");
        switch(i)
        {
        case 1:
            userPage();
            break;
        case 2:
            merchantPage();
            break;
        default:
            break;
        }
    }while(i);
    return 0;

}

